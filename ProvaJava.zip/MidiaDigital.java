import java.util.ArrayList;
public class MidiaDigital{

    public String Titulo;
    public Boolean Disponivel;

    public static ArrayList<MidiaDigital> midias = new ArrayList<MidiaDigital>();

}